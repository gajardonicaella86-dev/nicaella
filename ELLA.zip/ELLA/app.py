
from flask import (
    Flask, render_template_string, request, redirect,
    url_for, flash, jsonify, session
)
from pathlib import Path
from werkzeug.utils import secure_filename
from stack import Stack
import re

app = Flask(__name__)
app.secret_key = "girlyqtp-pop-local-key"

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
STATIC_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

profile = {
    "name": "GirlyQtPop by Nica Ella Gajardo",
    "bio": "Enjoy my works ig? haha.",
    "image": "profile.jpg"
}


# =========================================================
# INFIX TO POSTFIX CONVERTER
# =========================================================

def infix_to_postfix(expression):
    tokens = re.findall(
        r"\d+(?:\.\d+)?|[A-Za-z_]\w*|[()+\-*/%^]",
        expression
    )

    if not tokens or "".join(tokens) != re.sub(r"\s+", "", expression):
        raise ValueError("Please enter a valid expression.")

    precedence = {
        "+": 1,
        "-": 1,
        "*": 2,
        "/": 2,
        "%": 2,
        "^": 3
    }

    stack = Stack()
    output = []
    expect_operand = True

    for token in tokens:
        if re.fullmatch(r"\d+(?:\.\d+)?|[A-Za-z_]\w*", token):
            if not expect_operand:
                raise ValueError("Please check the operators in your expression.")

            output.append(token)
            expect_operand = False

        elif token == "(":
            if not expect_operand:
                raise ValueError("Please add an operator before '('.")
            stack.push(token)
            expect_operand = True

        elif token == ")":
            if expect_operand:
                raise ValueError("Invalid expression near ')'.")

            while not stack.is_empty() and stack.peek() != "(":
                output.append(stack.pop())

            if stack.is_empty():
                raise ValueError("Mismatched parentheses.")

            stack.pop()
            expect_operand = False

        elif token in precedence:
            if expect_operand:
                if token == "-":
                    output.append("0")
                else:
                    raise ValueError("An operator needs a value.")

            while (
                not stack.is_empty()
                and stack.peek() in precedence
                and (
                    precedence[stack.peek()] > precedence[token]
                    or (
                        precedence[stack.peek()] == precedence[token]
                        and token != "^"
                    )
                )
            ):
                output.append(stack.pop())

            stack.push(token)
            expect_operand = True

    if expect_operand:
        raise ValueError("Expression cannot end with an operator.")

    while not stack.is_empty():
        operator = stack.pop()

        if operator == "(":
            raise ValueError("Mismatched parentheses.")

        output.append(operator)

    return " ".join(output)


# =========================================================
# LINKED LIST
# =========================================================

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)

        if self.head is None:
            self.head = new_node
            return

        current = self.head
        while current.next:
            current = current.next

        current.next = new_node

    def delete(self, data):
        current = self.head
        previous = None

        while current:
            if current.data == data:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                return True

            previous = current
            current = current.next

        return False

    def to_list(self):
        values = []
        current = self.head

        while current:
            values.append(current.data)
            current = current.next

        return values


# =========================================================
# HTML TEMPLATE
# =========================================================

HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GirlyQtPop | Pink Studio</title>

<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@700;800&display=swap');

:root {
  --pink:#f23874;
  --rose:#f488ab;
  --ink:#57283f;
  --muted:#987185;
  --pale:#fff4f8;
  --line:#f1c8d8;
}

* { box-sizing:border-box; }

body {
  margin:0;
  min-height:100vh;
  font-family:'DM Sans',sans-serif;
  color:var(--ink);
  background:radial-gradient(circle at 50% 50%,#f23874,#f488ab);
  display:grid;
  place-items:center;
  padding:14px;
}

button,input,textarea { font:inherit; }
button { cursor:pointer; }

button:focus-visible,input:focus-visible,textarea:focus-visible {
  outline:3px solid #f2387480;
  outline-offset:3px;
}

.app {
  width:min(1180px,100%);
  height:min(790px,calc(100vh - 28px));
  min-height:480px;
  display:grid;
  grid-template-columns:215px minmax(0,1fr);
  overflow:hidden;
  background:#fff9fcf2;
  border:2px solid white;
  border-radius:25px;
  box-shadow:0 25px 75px #7d103b35;
  animation:enter .45s ease;
}

@keyframes enter {
  from { opacity:0; transform:translateY(12px); }
  to { opacity:1; transform:translateY(0); }
}

@keyframes float {
  50% { transform:translateY(-6px); }
}

.sidebar {
  padding:20px 12px;
  background:#fff9fbe8;
  border-right:1px solid var(--line);
  display:flex;
  flex-direction:column;
  min-height:0;
}

.brand {
  display:flex;
  align-items:center;
  gap:10px;
  padding:0 6px 25px;
}

.logo {
  width:42px;
  height:42px;
  display:grid;
  place-items:center;
  color:white;
  font-size:24px;
  background:linear-gradient(145deg,#ff78a7,#c91e60);
  border-radius:14px;
  flex-shrink:0;
}

.brand strong { font-size:14px; }

.brand small {
  display:block;
  margin-top:4px;
  color:var(--muted);
  font-size:9px;
  letter-spacing:2px;
}

.label {
  padding:8px 10px;
  color:#b48a9b;
  font-size:9px;
  font-weight:800;
  letter-spacing:2px;
}

.nav { display:grid; gap:7px; }

.nav button {
  display:flex;
  align-items:center;
  gap:10px;
  padding:10px;
  border:0;
  border-radius:12px;
  color:#82586b;
  background:transparent;
  text-align:left;
  font-size:12px;
  font-weight:700;
  transition:.2s;
}

.nav button:hover {
  background:#ffe7f0;
  transform:translateX(2px);
}

.nav button.active {
  color:white;
  background:linear-gradient(110deg,#f23b78,#d82264);
  box-shadow:0 7px 15px #d5226328;
}

.nav-icon {
  display:grid;
  place-items:center;
  flex-shrink:0;
  width:30px;
  height:30px;
  border-radius:10px;
  background:#ffe5ef;
  font-size:17px;
}

.nav button.active .nav-icon { background:#ffffff30; }

.side-note {
  margin-top:auto;
  padding:13px;
  border-radius:14px;
  background:#ffeaf2;
  color:var(--muted);
  font-size:10px;
  line-height:1.7;
}

.side-note strong {
  display:block;
  color:var(--ink);
}

.workspace {
  display:flex;
  flex-direction:column;
  min-width:0;
  min-height:0;
}

.topbar {
  height:57px;
  flex-shrink:0;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:8px;
  padding:0 24px;
  background:#fff9fc85;
  border-bottom:1px solid var(--line);
}

.breadcrumb {
  font-size:10px;
  color:var(--muted);
  font-weight:700;
}

.breadcrumb strong { color:var(--ink); }

.badge {
  padding:8px 11px;
  border-radius:30px;
  color:#b5245d;
  background:#ffe8f1;
  border:1px solid #f5cadb;
  font-size:9px;
  font-weight:800;
}

.pages {
  flex:1;
  min-height:0;
  overflow:hidden;
}

.page {
  display:none;
  height:100%;
  padding:25px;
  overflow-y:auto;
  scrollbar-width:thin;
  scrollbar-color:#edb3c9 transparent;
}

.page.active {
  display:block;
  animation:enter .25s ease;
}

.eyebrow {
  color:#c6326a;
  font-size:9px;
  font-weight:800;
  letter-spacing:2px;
}

h1 {
  margin:8px 0;
  color:#55243b;
  font:800 clamp(27px,3vw,37px) 'Playfair Display',Georgia,serif;
}

.description {
  color:var(--muted);
  font-size:12px;
  line-height:1.8;
}

.hero {
  display:grid;
  grid-template-columns:1.3fr .7fr;
  align-items:center;
  gap:12px;
  min-height:235px;
  padding:25px;
  overflow:hidden;
  border:1px solid white;
  border-radius:22px;
  background:linear-gradient(120deg,#fffafd,#ffe2ed);
}

.hero h1 {
  font-size:clamp(30px,3.5vw,43px);
  line-height:1.12;
  color:#a91c50;
}

.hero p {
  max-width:390px;
  color:#80586b;
  font-size:11px;
  line-height:1.8;
}

.hero-art {
  text-align:center;
  font-size:100px;
  animation:float 5s ease-in-out infinite;
}

.buttons {
  display:flex;
  flex-wrap:wrap;
  gap:9px;
  margin-top:15px;
}

.primary,.secondary {
  border-radius:11px;
  padding:11px 14px;
  font-size:10px;
  font-weight:800;
  transition:.2s;
}

.primary {
  color:white;
  background:linear-gradient(120deg,#f33e7b,#ca205e);
  border:0;
  box-shadow:0 4px 0 #a91a50;
}

.secondary {
  color:#bd245e;
  background:white;
  border:1px solid #f2c1d4;
}

.primary:hover,.secondary:hover { transform:translateY(-2px); }

.row-heading {
  display:flex;
  justify-content:space-between;
  align-items:end;
  gap:8px;
  margin:22px 0 12px;
}

.row-heading h2 { margin:0; font-size:15px; }

.row-heading span {
  color:var(--muted);
  font-size:9px;
}

.cards {
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:12px;
}

.card {
  min-width:0;
  padding:15px;
  text-align:left;
  color:var(--ink);
  background:var(--pale);
  border:1px solid white;
  border-radius:17px;
  transition:.2s;
}

.card:hover {
  transform:translateY(-4px);
  box-shadow:0 12px 25px #8b17421b;
}

.card-icon {
  width:40px;
  height:40px;
  display:grid;
  place-items:center;
  margin-bottom:12px;
  border-radius:12px;
  background:#ffe5ef;
  color:#bf205d;
  font-size:21px;
}

.card h3 { margin:0 0 7px; font-size:12px; }

.card p {
  margin:0;
  color:var(--muted);
  font-size:10px;
  line-height:1.7;
}

.card-link {
  display:block;
  margin-top:12px;
  color:#cc2764;
  font-size:10px;
  font-weight:800;
}

.reminder {
  display:flex;
  align-items:center;
  gap:12px;
  margin-top:14px;
  padding:13px;
  border:1px solid #f4cada;
  border-radius:14px;
  background:#fff0f6;
}

.reminder strong {
  display:block;
  margin-bottom:4px;
  font-size:10px;
}

.reminder span {
  color:var(--muted);
  font-size:9px;
  line-height:1.6;
}

.profile-grid {
  display:grid;
  grid-template-columns:.85fr 1.15fr;
  gap:14px;
  margin-top:20px;
}

.profile-card,.panel,.tool {
  min-width:0;
  padding:20px;
  background:#fffafd;
  border:1px solid white;
  border-radius:20px;
  box-shadow:0 12px 28px #8b17420d;
}

.profile-card {
  text-align:center;
  background:linear-gradient(150deg,#fffafd,#ffe4ef);
}

.avatar {
  width:140px;
  height:140px;
  margin:0 auto 15px;
  padding:4px;
  border-radius:50%;
  overflow:hidden;
  background:linear-gradient(145deg,#fa5c93,#bd2058);
  box-shadow:0 10px 24px #b91e5924;
  animation:float 5s ease-in-out infinite;
}

.avatar img {
  display:block;
  width:100%;
  height:100%;
  object-fit:cover;
  border:3px solid white;
  border-radius:50%;
}

.profile-card h2 {
  margin:5px 0;
  font:700 24px 'Playfair Display',Georgia,serif;
}

.role {
  color:#c12c65;
  font-size:9px;
  font-weight:800;
  letter-spacing:1px;
}

.profile-card p,.panel p {
  color:var(--muted);
  font-size:10px;
  line-height:1.9;
}

.panel h3,.tool h3 { margin-top:0; font-size:14px; }

.field { display:grid; gap:7px; margin:13px 0; }

.field label { font-size:10px; font-weight:800; }

.field input,.field textarea {
  width:100%;
  min-width:0;
  padding:12px;
  color:var(--ink);
  background:white;
  border:1px solid #efb6cc;
  border-radius:10px;
  outline:none;
  font-size:11px;
}

.field input:focus,.field textarea:focus {
  border-color:#e33c78;
  box-shadow:0 0 0 3px #f2387417;
}

.field input[type="file"] { padding:8px; }

.profile-tip {
  padding:12px;
  margin-top:12px;
  border-radius:12px;
  background:#ffeaf2;
  color:#86566d;
  font-size:10px;
  line-height:1.7;
}

.tool-grid {
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:13px;
  margin-top:18px;
}

.tool { padding:18px; }

.tool>p {
  color:var(--muted);
  font-size:10px;
  line-height:1.7;
}

.result {
  min-height:38px;
  margin-top:11px;
  padding:12px;
  overflow-wrap:anywhere;
  color:#a51c50;
  background:#ffe8f1;
  border-radius:10px;
  font-size:11px;
  font-weight:700;
}

.project-grid {
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:12px;
  margin-top:20px;
}

.project {
  padding:16px;
  color:var(--ink);
  text-align:left;
  background:#fffafd;
  border:1px solid white;
  border-radius:17px;
  transition:.2s;
}

.project:hover { transform:translateY(-4px); }

.project strong {
  display:block;
  margin:9px 0;
  font-size:12px;
}

.project small {
  color:var(--muted);
  font-size:10px;
  line-height:1.7;
}

.footer {
  display:flex;
  justify-content:space-between;
  gap:8px;
  flex-shrink:0;
  padding:11px 24px;
  color:#a57c8e;
  background:#fff9fc70;
  border-top:1px solid var(--line);
  font-size:9px;
}

.toast {
  position:fixed;
  z-index:10;
  left:50%;
  bottom:22px;
  max-width:90%;
  padding:12px 18px;
  color:white;
  background:#63253f;
  border-radius:30px;
  box-shadow:0 8px 25px #59102e30;
  font-size:11px;
  opacity:0;
  pointer-events:none;
  transform:translate(-50%,12px);
  transition:.25s;
}

.toast.show {
  opacity:1;
  transform:translate(-50%,0);
}

@media(max-width:900px) {
  .app { grid-template-columns:180px minmax(0,1fr); }
  .page { padding:18px; }
  .project-grid { grid-template-columns:repeat(2,minmax(0,1fr)); }
}

@media(max-width:760px) {
  body { padding:6px; }
  .app {
    height:calc(100vh - 12px);
    grid-template-columns:60px minmax(0,1fr);
    border-radius:18px;
  }
  .sidebar { padding:13px 5px; }
  .brand { justify-content:center; padding:0 0 20px; }
  .brand>div:last-child,.label,.nav-text,.side-note { display:none; }
  .nav button { justify-content:center; padding:7px 2px; }
  .nav-icon { width:34px; height:34px; }
  .topbar { height:50px; padding:0 10px; }
  .page { padding:15px 11px; }
  .hero { min-height:190px; grid-template-columns:1fr .35fr; padding:15px; }
  .hero h1 { font-size:26px; }
  .hero-art { font-size:58px; }
  .cards { gap:6px; }
  .card { padding:9px; }
  .card-icon { width:30px; height:30px; font-size:16px; }
  .card h3 { font-size:10px; }
  .card p { font-size:9px; }
  .profile-grid,.tool-grid,.project-grid { grid-template-columns:1fr; }
  .avatar { width:115px; height:115px; }
  .footer { padding:9px 10px; font-size:8px; }
}

@media(prefers-reduced-motion:reduce) {
  *,*::before,*::after {
    animation:none!important;
    transition:none!important;
    scroll-behavior:auto!important;
  }
}
</style>
</head>

<body>
<div class="app">
<aside class="sidebar">
  <div class="brand">
    <div class="logo">✿</div>
    <div><strong>GirlyQtPop</strong><small>PINK STUDIO</small></div>
  </div>

  <div class="label">WORKSPACE</div>

  <nav class="nav">
    <button class="active" data-page="home"><span class="nav-icon">⌂</span><span class="nav-text">Home</span></button>
    <button data-page="profile"><span class="nav-icon">♡</span><span class="nav-text">My Profile</span></button>
    <button data-page="tools"><span class="nav-icon">∑</span><span class="nav-text">Math Tools</span></button>
    <button data-page="stack"><span class="nav-icon">▤</span><span class="nav-text">Stack</span></button>
    <button data-page="linkedlist"><span class="nav-icon">↔</span><span class="nav-text">Linked List</span></button>
    <button data-page="works"><span class="nav-icon">▧</span><span class="nav-text">My Works</span></button>
    <button data-page="about"><span class="nav-icon">✧</span><span class="nav-text">About</span></button>
  </nav>

  <div class="side-note">
    <strong>♡ A little reminder</strong>
    Keep learning, keep creating, and make every small step count.
  </div>
</aside>

<section class="workspace">
<header class="topbar">
  <div class="breadcrumb">PINK STUDIO / <strong id="breadcrumb">HOME</strong></div>
  <div class="badge">✦ BSCPE 2-3 <3</div>
</header>

<main class="pages">

<section class="page active" id="home">
  <div class="hero">
    <div>
      <div class="eyebrow">YOUR CREATIVE CORNER</div>
      <h1>Pretty ideas.<br>Smart solutions.</h1>
      <p>Welcome to GirlyQtPop — a polished space for handy calculators, creative work, and a touch of pink magic.</p>
      <div class="buttons">
        <button class="primary" onclick="go('tools')">Explore math tools ↗</button>
        <button class="secondary" onclick="go('profile')">Meet the creator ♡</button>
      </div>
    </div>
    <div class="hero-art" aria-hidden="true">🌸</div>
  </div>

  <div class="row-heading"><h2>Choose your destination</h2><span>CLICK A CARD TO OPEN</span></div>

  <div class="cards">
    <button class="card" onclick="go('profile')">
      <div class="card-icon">♡</div>
      <h3>Creator Profile</h3>
      <p>Meet the person behind the pink studio.</p>
      <span class="card-link">View profile ↗</span>
    </button>

    <button class="card" onclick="go('tools')">
      <div class="card-icon">∑</div>
      <h3>Quick Math Tools</h3>
      <p>Convert text and calculate shapes instantly.</p>
      <span class="card-link">Open tools ↗</span>
    </button>

    <button class="card" onclick="go('works')">
      <div class="card-icon">✧</div>
      <h3>Works & Projects</h3>
      <p>Explore the features on this website.</p>
      <span class="card-link">Explore works ↗</span>
    </button>
  </div>

  <div class="reminder">
    <div>✦</div>
    <div><strong>Made to be simple, useful, and magical.</strong><span>Use the navigation to switch pages without scrolling through Home.</span></div>
  </div>
</section>

<section class="page" id="profile">
  <div class="eyebrow">THE CREATOR</div>
  <h1>A little about me</h1>
  <p class="description">Upload your own photo and customize the profile details.</p>

  <div class="profile-grid">
    <div class="profile-card">
      <div class="avatar">
        <img id="profileImage" src="{{ url_for('static', filename=profile_image) }}" alt="Your profile picture">
      </div>
      <h2 id="profileName">{{ profile_name }}</h2>
      <div class="role">CREATIVE STUDENT · MATH ENTHUSIAST</div>
      <p id="profileBio">{{ profile_bio }}</p>

      <form action="{{ url_for('upload_profile') }}" method="post" enctype="multipart/form-data" id="uploadForm">
        <div class="field">
          <label for="photo">Choose your profile picture</label>
          <input type="file" name="photo" id="photo" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" required>
        </div>
        <button class="primary" type="submit">Upload & save photo ♡</button>
      </form>

      <div class="profile-tip">Use a JPG, PNG, or WEBP image. A square or portrait photo works best.</div>
    </div>

    <div class="panel">
      <h3>Profile details</h3>
      <p>Update your display name and personal description.</p>
      <form action="{{ url_for('save_profile') }}" method="post">
        <div class="field">
          <label for="name">Display name</label>
          <input id="name" name="name" maxlength="32" required value="{{ profile_name }}">
        </div>
        <div class="field">
          <label for="bio">Short bio</label>
          <textarea id="bio" name="bio" rows="4" maxlength="180">{{ profile_bio }}</textarea>
        </div>
        <button class="primary" type="submit">Save profile details ♡</button>
      </form>
      <div class="profile-tip">Your profile image is saved in the project's static folder.</div>
    </div>
  </div>
</section>

<section class="page" id="tools">
  <div class="eyebrow">USEFUL LITTLE UTILITIES</div>
  <h1>Math & text tools</h1>
  <p class="description">Enter a value and get an instant result.</p>

  <div class="tool-grid">
    <div class="tool">
      <h3>✦ Uppercase Converter</h3>
      <p>Convert text into uppercase letters.</p>
      <div class="field"><label for="textInput">Enter text</label><input id="textInput" placeholder="Type something here..."></div>
      <button class="primary" onclick="convertText()">Convert text ♡</button>
      <div class="result" id="textResult">Your converted text will appear here.</div>
      <button class="secondary" style="margin-top:8px" onclick="copyText()">Copy result</button>
    </div>

    <div class="tool">
      <h3>◉ Circle Area Calculator</h3>
      <p>Formula: π × radius²</p>
      <div class="field"><label for="radius">Radius</label><input id="radius" type="number" min="0" step="any" placeholder="Example: 5"></div>
      <button class="primary" onclick="circleArea()">Calculate area ♡</button>
      <div class="result" id="circleResult">Your answer will appear here.</div>
    </div>

    <div class="tool">
      <h3>▱ Rectangle Area Calculator</h3>
      <p>Formula: length × width</p>
      <div class="field"><label for="length">Length</label><input id="length" type="number" min="0" step="any" placeholder="Example: 10"></div>
      <div class="field"><label for="width">Width</label><input id="width" type="number" min="0" step="any" placeholder="Example: 4"></div>
      <button class="primary" onclick="rectangleArea()">Calculate area ♡</button>
      <div class="result" id="rectResult">Your answer will appear here.</div>
    </div>

    <div class="tool">
      <h3>⌁ Infix to Postfix Converter</h3>
      <p>Convert expressions using a stack. Use spaces for clarity, for example A + B * C.</p>
      <div class="field"><label for="infixInput">Infix expression</label><input id="infixInput" placeholder="A + B * C"></div>
      <button class="primary" onclick="convertInfix()">Convert ♡</button>
      <div class="result" id="postfixResult">Your postfix result will appear here.</div>
    </div>

    <div class="tool">
      <h3>▤ Stack Operations</h3>
      <p>Try Push, Pop, Peek, and Clear.</p>
      <div class="field"><label for="stackInput">Value to push</label><input id="stackInput" placeholder="Enter a value"></div>
      <div class="buttons">
        <button class="primary" onclick="stackAction('push')">Push</button>
        <button class="secondary" onclick="stackAction('pop')">Pop</button>
        <button class="secondary" onclick="stackAction('peek')">Peek</button>
        <button class="secondary" onclick="stackAction('clear')">Clear</button>
      </div>
      <div class="result" id="stackResult">Stack is empty.</div>
      <div class="result" id="stackMessage">Choose an operation.</div>
    </div>

    <div class="tool">
      <h3>⌁ Quick controls</h3>
      <p>Clear the calculator and text-converter inputs.</p>
      <button class="secondary" onclick="clearTools()">Clear math & text inputs</button>
      <div class="result">Small steps make big progress ✨</div>
    </div>
  </div>
</section>

<section class="page" id="stack">
  <div class="eyebrow">DATA STRUCTURES</div>
  <h1>Stack Workspace</h1>
  <p class="description">Stack follows Last In, First Out (LIFO).</p>

  <div class="tool-grid">
    <div class="tool">
      <h3>Stack Visualization</h3>
      <p>The most recently pushed item appears at the top.</p>
      <div class="result" id="stackVisual">Stack is empty.</div>
    </div>
    <div class="tool">
      <h3>Stack Operations</h3>
      <p>Use the controls in Math Tools to push, pop, peek, or clear values.</p>
      <button class="primary" onclick="go('tools')">Open Stack Controls ↗</button>
    </div>
  </div>
</section>

<section class="page" id="linkedlist">
  <div class="eyebrow">DATA STRUCTURES</div>
  <h1>Linked List</h1>
  <p class="description">Add, delete, and view nodes in a singly linked list.</p>

  <div class="tool-grid">
    <div class="tool">
      <h3>↔ Linked List Operations</h3>
      <div class="field"><label for="listInput">Node value</label><input id="listInput" placeholder="Enter a value"></div>
      <div class="buttons">
        <button class="primary" onclick="linkedListAction('add')">Add Node</button>
        <button class="secondary" onclick="linkedListAction('delete')">Delete Node</button>
        <button class="secondary" onclick="linkedListAction('clear')">Clear List</button>
      </div>
      <div class="result" id="listResult">Linked list is empty.</div>
      <div class="result" id="listMessage">Add a node to begin.</div>
    </div>
    <div class="tool">
      <h3>How it works</h3>
      <p>Each node contains a value and a reference to the next node.</p>
      <div class="result">HEAD → Node → Node → None</div>
    </div>
  </div>
</section>

<section class="page" id="works">
  <div class="eyebrow">FEATURES & PROJECTS</div>
  <h1>Made with purpose</h1>
  <p class="description">Choose a project to open its corresponding tool.</p>

  <div class="project-grid">
    <button class="project" onclick="openTool('textInput')"><div class="card-icon">Aa</div><strong>Text Transformer</strong><small>Convert sentences into uppercase.</small><span class="card-link">Try it ↗</span></button>
    <button class="project" onclick="openTool('radius')"><div class="card-icon">◉</div><strong>Circle Calculator</strong><small>Calculate a circle's area using its radius.</small><span class="card-link">Try it ↗</span></button>
    <button class="project" onclick="openTool('length')"><div class="card-icon">▱</div><strong>Rectangle Calculator</strong><small>Calculate area using length and width.</small><span class="card-link">Try it ↗</span></button>
    <button class="project" onclick="openTool('infixInput')"><div class="card-icon">⌁</div><strong>Infix to Postfix</strong><small>Convert expressions using operator precedence and a stack.</small><span class="card-link">Try it ↗</span></button>
    <button class="project" onclick="go('stack')"><div class="card-icon">▤</div><strong>Stack Operations</strong><small>Practice Push, Pop, Peek, and Clear.</small><span class="card-link">Open stack ↗</span></button>
    <button class="project" onclick="go('linkedlist')"><div class="card-icon">↔</div><strong>Linked List</strong><small>Add, delete, and view linked-list nodes.</small><span class="card-link">Open linked list ↗</span></button>
  </div>
</section>

<section class="page" id="about">
  <div class="eyebrow">OUR LITTLE STUDIO</div>
  <h1>About GirlyQtPop</h1>
  <p class="description">A pink-themed website combining friendly visuals with practical tools.</p>

  <div class="profile-grid">
    <div class="panel">
      <div class="card-icon">✿</div>
      <h2>Soft design.<br>Smart function.</h2>
      <p>Inspired by pink gradients, rounded panels, gentle motion, and simple navigation.</p>
      <button class="primary" onclick="go('tools')">Use the tools ↗</button>
    </div>
    <div class="panel">
      <h3>Features</h3>
      <p>♡ Fixed clickable sidebar navigation</p>
      <p>✦ Uppercase text converter</p>
      <p>◉ Circle and rectangle calculators</p>
      <p>⌁ Infix to Postfix Converter</p>
      <p>▤ Stack operations using stack.py</p>
      <p>↔ Linked List operations</p>
      <p>✧ Profile picture upload and editing</p>
    </div>
  </div>
</section>

</main>
<footer class="footer"><span>© 2026 GIRLYQTPOP STUDIO</span><span>DESIGNED IN PINK ♡</span></footer>
</section>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script>
const titles = {
  home: "HOME",
  profile: "MY PROFILE",
  tools: "MATH TOOLS",
  stack: "STACK",
  linkedlist: "LINKED LIST",
  works: "MY WORKS",
  about: "ABOUT"
};

function go(page) {
  document.querySelectorAll(".page").forEach(p =>
    p.classList.toggle("active", p.id === page)
  );

  document.querySelectorAll(".nav button").forEach(b =>
    b.classList.toggle("active", b.dataset.page === page)
  );

  document.getElementById("breadcrumb").textContent = titles[page] || "HOME";
}

document.querySelectorAll(".nav button").forEach(button => {
  button.addEventListener("click", () => go(button.dataset.page));
});

function toast(message) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.classList.add("show");

  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    element.classList.remove("show");
  }, 2400);
}

document.getElementById("photo").addEventListener("change", function() {
  const file = this.files[0];
  if (!file) return;

  if (!file.type.startsWith("image/")) {
    toast("Please choose an image file.");
    this.value = "";
    return;
  }

  const reader = new FileReader();
  reader.onload = event => {
    document.getElementById("profileImage").src = event.target.result;
  };
  reader.readAsDataURL(file);
});

function convertText() {
  const value = document.getElementById("textInput").value;
  document.getElementById("textResult").textContent =
    value.trim() ? value.toLocaleUpperCase() : "Please enter some text first.";
}

async function copyText() {
  const value = document.getElementById("textResult").textContent;

  if (!value || value.includes("appear here") ||
      value === "Please enter some text first.") {
    toast("Nothing to copy yet.");
    return;
  }

  try {
    await navigator.clipboard.writeText(value);
    toast("Copied to clipboard ♡");
  } catch (error) {
    toast("Clipboard is unavailable in this browser.");
  }
}

function num(id) {
  const value = document.getElementById(id).value.trim();
  if (value === "") return null;

  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : NaN;
}

function fmt(number) {
  return number.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

function circleArea() {
  const radius = num("radius");
  const output = document.getElementById("circleResult");

  if (radius === null || Number.isNaN(radius)) {
    output.textContent = "Enter a valid non-negative radius.";
    return;
  }

  output.textContent =
    "Circle area: " + fmt(Math.PI * radius * radius) + " square units";
}

function rectangleArea() {
  const length = num("length");
  const width = num("width");
  const output = document.getElementById("rectResult");

  if (length === null || width === null ||
      Number.isNaN(length) || Number.isNaN(width)) {
    output.textContent = "Enter valid non-negative measurements.";
    return;
  }

  output.textContent =
    "Rectangle area: " + fmt(length * width) + " square units";
}

function clearTools() {
  ["textInput", "radius", "length", "width"].forEach(id => {
    document.getElementById(id).value = "";
  });

  document.getElementById("textResult").textContent =
    "Your converted text will appear here.";
  document.getElementById("circleResult").textContent =
    "Your answer will appear here.";
  document.getElementById("rectResult").textContent =
    "Your answer will appear here.";

  toast("Math and text inputs cleared ♡");
}

function openTool(id) {
  go("tools");
  setTimeout(() => {
    const element = document.getElementById(id);
    if (element) element.focus();
  }, 100);
}

async function postData(url, data) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "Something went wrong.");
  }

  return result;
}

async function convertInfix() {
  const expression = document.getElementById("infixInput").value.trim();
  const output = document.getElementById("postfixResult");

  try {
    const data = await postData("/api/infix-to-postfix", { expression });
    output.textContent = "Postfix: " + data.result;
  } catch (error) {
    output.textContent = error.message;
  }
}

function renderStack(data) {
  const display = data.items.length
    ? "Bottom → " + data.items.join(" | ") + " ← Top"
    : "Stack is empty.";

  document.getElementById("stackResult").textContent = display;
  document.getElementById("stackVisual").textContent = display;
}

async function stackAction(action) {
  const input = document.getElementById("stackInput");
  const value = input.value.trim();

  if (action === "push" && !value) {
    document.getElementById("stackMessage").textContent =
      "Enter a value to push.";
    return;
  }

  try {
    const data = await postData("/api/stack", { action, value });
    renderStack(data);
    document.getElementById("stackMessage").textContent = data.message;

    if (action === "push") input.value = "";
  } catch (error) {
    document.getElementById("stackMessage").textContent = error.message;
  }
}

async function linkedListAction(action) {
  const input = document.getElementById("listInput");
  const value = input.value.trim();

  if (action !== "clear" && !value) {
    document.getElementById("listMessage").textContent =
      "Enter a node value first.";
    return;
  }

  try {
    const data = await postData("/api/linked-list", { action, value });

    document.getElementById("listResult").textContent =
      data.items.length
        ? "HEAD → " + data.items.join(" → ") + " → None"
        : "Linked list is empty.";

    document.getElementById("listMessage").textContent = data.message;

    if (action === "add" || action === "delete") {
      input.value = "";
    }
  } catch (error) {
    document.getElementById("listMessage").textContent = error.message;

    if (error.items) {
      document.getElementById("listResult").textContent =
        error.items.length
          ? "HEAD → " + error.items.join(" → ") + " → None"
          : "Linked list is empty.";
    }
  }
}

document.addEventListener("keydown", event => {
  if (event.key === "Escape") go("home");

  if (event.altKey && ["1", "2", "3", "4", "5"].includes(event.key)) {
    go(["home", "profile", "tools", "works", "about"][Number(event.key) - 1]);
  }
});
</script>
</body>
</html>
"""


# =========================================================
# PROFILE HELPERS AND ROUTES
# =========================================================

def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


@app.route("/")
def home():
    return render_template_string(
        HTML,
        profile_name=profile["name"],
        profile_bio=profile["bio"],
        profile_image=profile["image"]
    )


@app.route("/upload-profile", methods=["POST"])
def upload_profile():
    photo = request.files.get("photo")

    if not photo or not photo.filename:
        flash("Please select a picture first.")
        return redirect(url_for("home"))

    if not allowed_file(photo.filename):
        flash("Please use JPG, JPEG, PNG, or WEBP.")
        return redirect(url_for("home"))

    extension = photo.filename.rsplit(".", 1)[1].lower()
    if extension == "jpeg":
        extension = "jpg"

    filename = "profile." + extension
    destination = STATIC_DIR / filename
    photo.save(destination)

    profile["image"] = filename
    return redirect(url_for("home"))


@app.route("/save-profile", methods=["POST"])
def save_profile():
    name = request.form.get("name", "").strip()[:32]
    bio = request.form.get("bio", "").strip()[:180]

    if not name:
        flash("Display name cannot be empty.")
        return redirect(url_for("home"))

    profile["name"] = name
    profile["bio"] = bio

    return redirect(url_for("home"))


# =========================================================
# INFIX TO POSTFIX API
# =========================================================

@app.route("/api/infix-to-postfix", methods=["POST"])
def api_infix_to_postfix():
    data = request.get_json(silent=True) or {}
    expression = str(data.get("expression", ""))

    try:
        result = infix_to_postfix(expression)
        return jsonify({"result": result})
    except ValueError as error:
        return jsonify({"error": str(error)}), 400


# =========================================================
# STACK API
# =========================================================

@app.route("/api/stack", methods=["POST"])
def api_stack():
    data = request.get_json(silent=True) or {}
    action = data.get("action")
    value = str(data.get("value", "")).strip()

    items = session.get("stack_items", [])
    stack = Stack()

    for item in items:
        stack.push(item)

    if action == "push":
        if not value:
            return jsonify({"error": "Enter a value to push."}), 400

        stack.push(value)
        message = f"Pushed: {value}"

    elif action == "pop":
        removed = stack.pop()
        message = (
            f"Popped: {removed}"
            if removed is not None
            else "Stack is empty."
        )

    elif action == "peek":
        top = stack.peek()
        message = (
            f"Top item: {top}"
            if top is not None
            else "Stack is empty."
        )

    elif action == "clear":
        stack.clear()
        message = "Stack cleared."

    else:
        return jsonify({"error": "Unknown stack operation."}), 400

    session["stack_items"] = stack.to_list()

    return jsonify({
        "items": stack.to_list(),
        "message": message
    })


# =========================================================
# LINKED LIST API
# =========================================================

@app.route("/api/linked-list", methods=["POST"])
def api_linked_list():
    data = request.get_json(silent=True) or {}
    action = data.get("action")
    value = str(data.get("value", "")).strip()

    items = session.get("linked_list_items", [])
    current_list = LinkedList()

    for item in items:
        current_list.append(item)

    if action == "add":
        if not value:
            return jsonify({"error": "Enter a node value."}), 400

        current_list.append(value)
        message = f"Added node: {value}"

    elif action == "delete":
        if not current_list.delete(value):
            return jsonify({
                "error": f"Node '{value}' was not found.",
                "items": current_list.to_list()
            }), 404

        message = f"Deleted node: {value}"

    elif action == "clear":
        current_list = LinkedList()
        message = "Linked list cleared."

    else:
        return jsonify({"error": "Unknown linked-list operation."}), 400

    session["linked_list_items"] = current_list.to_list()

    return jsonify({
        "items": current_list.to_list(),
        "message": message
    })


if __name__ == "__main__":
    app.run(debug=True)
